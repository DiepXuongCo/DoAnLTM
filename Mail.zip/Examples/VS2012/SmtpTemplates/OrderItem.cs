namespace SmtpTemplates
{
    internal class OrderItem
    {
        public string Name { get; set; }
        public string Quantity { get; set; }
        public decimal Price { get; set; }
    };
}